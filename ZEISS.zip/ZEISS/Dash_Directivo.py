import dash
from dash import html, dcc, callback, Input, Output, dash_table
import plotly.graph_objs as go
import pandas as pd
import plotly         
import plotly.express as px
import plotly.io as pio
import plotly.graph_objs as go 


#DATA
DATA = pd.read_csv('/Users/minellygonzalezalva/Documents/LAF/7mo/Dash/BASES/VPT_Opp_v3_MX_num_chida.csv')
UNO = pd.read_csv('/Users/minellygonzalezalva/Documents/LAF/7mo/Dash/BASES/Status_LastChange.csv')
DOS = pd.read_csv('/Users/minellygonzalezalva/Documents/LAF/7mo/Dash/BASES/Rep_Status.csv')
TRES = pd.read_csv('/Users/minellygonzalezalva/Documents/LAF/7mo/Dash/BASES/Edos_Status.csv')
#MODIFICACIONES
DATA['Last Change'] = pd.to_datetime(DATA['Last Change'])
UNO['Last Change'] = pd.to_datetime(UNO['Last Change'])
DOS['Last Change'] = pd.to_datetime(DOS['Last Change'])
#CÁLCULOS
UNO['Total'] = UNO['Discontinued'] + UNO['In process'] + UNO['Lost'] + UNO['Won']
DOS['Total'] = DOS['Discontinued'] + DOS['In process'] + DOS['Lost'] + DOS['Won']
TRES['Total'] = TRES['Discontinued'] + TRES['In process'] + TRES['Lost'] + TRES['Won']
#NUEVAS BASES
DOS1 = DOS.groupby(['Last Change', 'Sales Rep 2'])[['In process', 'Won', 'Lost', 'Discontinued','Total']].sum().reset_index()

TRES_dict = TRES[['ENTIDAD', 'Latitude', 'Longitude']]
list_locations = TRES_dict.set_index('ENTIDAD')[['Latitude', 'Longitude']].T.to_dict('dict')

app = dash.Dash(__name__, meta_tags=[{"name": "viewport", "content": "width=device-width"}])

app.layout = html.Div([
    #ENCABEZADO
    html.Div([
        #LOGO ZEISS
        html.Div([
            html.Img(src=app.get_asset_url('LOGO_ZEISS2.png'),
                     id='ZEISS_LOGO',
                     style={
                         "height": "80px",
                         "width": "auto",
                         "margin-bottom": "5px",
                     },
                     )
        ],
            className="one-third column",
        ),
        #TÍTULO
        html.Div([
            html.Div([
                html.H3("ZEISS", style={"margin-bottom": "0px", 'color': '#141e8c'}),
                html.H5("Dashboard Directivo", style={"margin-top": "0px", 'color': '#414142'}),
            ])
        ], className="one-half column", id="title"),
        #ÚLTIMA ACTUALIZACIÓN
        html.Div([
            html.H6('Última actualización: ' + str(DATA['Last Change'].iloc[-1].strftime("%B %d, %Y")),
                    style={'color': '#141e8c'}),

        ], className="one-third column", id='title1'),
    ], id="header", className="row flex-display", style={"margin-bottom": "25px"}),

    #PRIMERA DIVISIÓN
    html.Div([
        #PARTE 1.1
        html.Div([
            html.H2(children='Estadísticas generales',
            style = {'color' : 'white','fontsize': 15, 'textAlign': 'center'}),
        ]),
    ]),
    html.Div([
        html.Div([
            html.H6(children='Tratos ganados',
                    style={
                        'textAlign': 'center',
                        'color': '#141e8c'}
                    ),

            html.P(f"{UNO['Won'].iloc[-1]:,.0f}",
                   style={
                       'textAlign': 'center',
                       'color': '#078739',
                       'fontSize': 40}
                   ),

            html.P('Nuevos:  ' + f"{UNO['Won'].iloc[-1] - UNO['Won'].iloc[-2]:,.0f} "
                   + ' (' + str(round(((UNO['Won'].iloc[-1] - UNO['Won'].iloc[-2]) /
                                       UNO['Won'].iloc[-1]) * 100, 2)) + '%)',
                   style={
                       'textAlign': 'center',
                       'color': '#078739',
                       'fontSize': 15,
                       'margin-top': '-18px'}
                   )], className="card_container three columns",
        ),
        #PARTE 1.2
        html.Div([
            html.H6(children='Tratos perdidos',
                    style={
                        'textAlign': 'center',
                        'color': '#141e8c'}
                    ),

            html.P(f"{UNO['Lost'].iloc[-1]:,.0f}",
                   style={
                       'textAlign': 'center',
                       'color': '#fa4257',
                       'fontSize': 40}
                   ),

            html.P('Nuevos:  ' + f"{UNO['Lost'].iloc[-1] - UNO['Lost'].iloc[-2]:,.0f} "
                   + ' (' + str(round(((UNO['Lost'].iloc[-1] - UNO['Lost'].iloc[-2]) /
                                       UNO['Lost'].iloc[-1]) * 100, 2)) + '%)',
                   style={
                       'textAlign': 'center',
                       'color': '#fa4257',
                       'fontSize': 15,
                       'margin-top': '-18px'}
                   )], className="card_container three columns",
        ),
        #PARTE 1.3
        html.Div([
            html.H6(children='Tratos en proceso',
                    style={
                        'textAlign': 'center',
                        'color': '#141e8c'}
                    ),

            html.P(f"{UNO['In process'].iloc[-1]:,.0f}",
                   style={
                       'textAlign': 'center',
                       'color': '#e89005',
                       'fontSize': 40}
                   ),

            html.P('Nuevos:  ' + f"{UNO['In process'].iloc[-1] - UNO['In process'].iloc[-2]:,.0f} "
                   + ' (' + str(round(((UNO['In process'].iloc[-1] - UNO['In process'].iloc[-2]) /
                                       UNO['In process'].iloc[-1]) * 100, 2)) + '%)',
                   style={
                       'textAlign': 'center',
                       'color': '#e89005',
                       'fontSize': 15,
                       'margin-top': '-18px'}
                   )], className="card_container three columns",
        ),
        #PARTE 1.4
        html.Div([
            html.H6(children='Tratos totales',
                    style={
                        'textAlign': 'center',
                        'color': '#141e8c'}
                    ),

            html.P(f"{UNO['Total'].iloc[-1]:,.0f}",
                   style={
                       'textAlign': 'center',
                       'color': '#AC43B8',
                       'fontSize': 40}
                   ),

            html.P('Nuevos:  ' + f"{UNO['Total'].iloc[-1] - UNO['Total'].iloc[-2]:,.0f} "
                   + ' (' + str(round(((UNO['Total'].iloc[-1] - UNO['Total'].iloc[-2]) /
                                       UNO['Total'].iloc[-1]) * 100, 2)) + '%)',
                   style={
                       'textAlign': 'center',
                       'color': '#AC43B8',
                       'fontSize': 15,
                       'margin-top': '-18px'}
                   )], className="card_container three columns")
    ], className="row flex-display"),

    #SEGUNDA DIVISIÓN
    html.Div([
        #PARTE 2.1
        html.Div([
                    html.P('Seleccione vendedor:', className='fix_label',  style={'color': '#141e8c'}),

                     dcc.Dropdown(id='w_trato',
                                  multi=False,
                                  clearable=True,
                                  value='Luis Fernando Lyn Mendez Laguna',
                                  placeholder='Seleccione un vendedor',
                                  options=[{'label': c, 'value': c}
                                           for c in (DOS['Sales Rep 2'].unique())], className='dcc_compon'),

                     html.P('Actualización: ' + '  ' + ' ' + str(DOS1['Last Change'].iloc[-1].strftime("%B %d, %Y")) + '  ', className='fix_label',  style={'color': '#141e8c', 'text-align': 'center'}),
                     dcc.Graph(id='In process', config={'displayModeBar': False}, className='dcc_compon',
                     style={'margin-top': '20px'},
                     ),

                      dcc.Graph(id='Won', config={'displayModeBar': False}, className='dcc_compon',
                      style={'margin-top': '20px'},
                      ),

                      dcc.Graph(id='Lost', config={'displayModeBar': False}, className='dcc_compon',
                      style={'margin-top': '20px'},
                      ),

                      dcc.Graph(id='Discontinued', config={'displayModeBar': False}, className='dcc_compon',
                      style={'margin-top': '20px'},
                      ),

                      dcc.Graph(id='Total', config={'displayModeBar': False}, className='dcc_compon',
                      style={'margin-top': '20px'},
                      ),

        ], className="create_container three columns", id="cross-filter-options"),
        #PARTE 2.2
            html.Div([
                      dcc.Graph(id='pie_chart',
                              config={'displayModeBar': 'hover'}),
                              ], className="create_container four columns"),
        #PARTE 2.3
                    html.Div([
                        dcc.Graph(id="line_chart")

                    ], className="create_container five columns"),
        ], className="row flex-display"),
#TERCERA DIVISIÓN
html.Div([
        html.Div([
            dcc.Graph(id="map")], className="create_container1 twelve columns"),

            ], className="row flex-display"),
    ], id="mainContainer",
    style={"display": "flex", "flex-direction": "column"})

#CALLBACKS
    #PARTE 2.1.1
@app.callback(
    Output('In process', 'figure'),
    [Input('w_trato', 'value')])
def update_confirmed(w_trato):
    DOS1 = DOS.groupby(['Last Change', 'Sales Rep 2'])[['In process', 'Won', 'Lost', 'Discontinued', 'Total']].sum().reset_index()

    value_process = DOS1[DOS1['Sales Rep 2'] == w_trato]['In process'].iloc[-1] - DOS1[DOS1['Sales Rep 2'] == w_trato]['In process'].iloc[-2]
    delta_process = DOS1[DOS1['Sales Rep 2'] == w_trato]['In process'].iloc[-2] - DOS1[DOS1['Sales Rep 2'] == w_trato]['In process'].iloc[-3]
    return {
            'data': [go.Indicator(
                    mode='number+delta',
                    value=value_process,
                    delta={'reference': delta_process,
                              'position': 'right',
                              'valueformat': ',g',
                              'relative': True,

                              'font': {'size': 12}},
                    number={'valueformat': ',',
                            'font': {'size': 15},

                               },
                    domain={'y': [0, 1], 'x': [0, 1]})],
            'layout': go.Layout(
                title={'text': 'En proceso:',
                       'y': 1,
                       'x': 0.5,
                       'xanchor': 'center',
                       'yanchor': 'top'},
                font=dict(color='#e89005'),
                paper_bgcolor='#ededfc',
                plot_bgcolor='#ededfc',
                height=50
                ),

            }
    #PARTE 2.1.2
@app.callback(
    Output('Won', 'figure'),
    [Input('w_trato', 'value')])
def update_confirmed(w_trato):
    DOS1 = DOS.groupby(['Last Change', 'Sales Rep 2'])[['In process', 'Won', 'Lost', 'Discontinued','Total']].sum().reset_index()

    value_won = DOS1[DOS1['Sales Rep 2'] == w_trato]['Won'].iloc[-1] - DOS1[DOS1['Sales Rep 2'] == w_trato]['Won'].iloc[-2]
    delta_won = DOS1[DOS1['Sales Rep 2'] == w_trato]['Won'].iloc[-2] - DOS1[DOS1['Sales Rep 2'] == w_trato]['Won'].iloc[-3]

    return {
            'data': [go.Indicator(
                    mode='number+delta',
                    value=value_won,
                    delta={'reference': delta_won,
                              'position': 'right',
                              'valueformat': ',g',
                              'relative': True,

                              'font': {'size': 12}},
                    number={'valueformat': ',',
                            'font': {'size': 15},

                               },
                    domain={'y': [0, 1], 'x': [0, 1]})],
            'layout': go.Layout(
                title={'text': 'Ganados:',
                       'y': 1,
                       'x': 0.5,
                       'xanchor': 'center',
                       'yanchor': 'top'},
                font=dict(color='#078739'),
                paper_bgcolor='#ededfc',
                plot_bgcolor='#ededfc',
                height=50
                ),

            }
    #PARTE 2.1.3
@app.callback(
    Output('Lost', 'figure'),
    [Input('w_trato', 'value')])
def update_confirmed(w_trato):
    DOS1 = DOS.groupby(['Last Change', 'Sales Rep 2'])[['In process', 'Won', 'Lost', 'Discontinued','Total']].sum().reset_index()

    value_lost = DOS1[DOS1['Sales Rep 2'] == w_trato]['Lost'].iloc[-1] - DOS1[DOS1['Sales Rep 2'] == w_trato]['Lost'].iloc[-2]
    delta_lost = DOS1[DOS1['Sales Rep 2'] == w_trato]['Lost'].iloc[-2] - DOS1[DOS1['Sales Rep 2'] == w_trato]['Lost'].iloc[-3]
    return {
            'data': [go.Indicator(
                    mode='number+delta',
                    value=value_lost,
                    delta={'reference': delta_lost,
                              'position': 'right',
                              'valueformat': ',g',
                              'relative': True,

                              'font': {'size': 12}},
                    number={'valueformat': ',',
                            'font': {'size': 15},

                               },
                    domain={'y': [0, 1], 'x': [0, 1]})],
            'layout': go.Layout(
                title={'text': 'Perdidos:',
                       'y': 1,
                       'x': 0.5,
                       'xanchor': 'center',
                       'yanchor': 'top'},
                font=dict(color='#fa4257'),
                paper_bgcolor='#ededfc',
                plot_bgcolor='#ededfc',
                height=50
                ),

            }
    #PARTE 2.1.4
@app.callback(
    Output('Discontinued', 'figure'),
    [Input('w_trato', 'value')])
def update_confirmed(w_trato):
    DOS1 = DOS.groupby(['Last Change', 'Sales Rep 2'])[['In process', 'Won', 'Lost', 'Discontinued','Total']].sum().reset_index()

    value_dis = DOS1[DOS1['Sales Rep 2'] == w_trato]['Discontinued'].iloc[-1] - DOS1[DOS1['Sales Rep 2'] == w_trato]['Discontinued'].iloc[-2]
    delta_dis = DOS1[DOS1['Sales Rep 2'] == w_trato]['Discontinued'].iloc[-2] - DOS1[DOS1['Sales Rep 2'] == w_trato]['Discontinued'].iloc[-3]
    return {
            'data': [go.Indicator(
                    mode='number+delta',
                    value=value_dis,
                    delta={'reference': delta_dis,
                              'position': 'right',
                              'valueformat': ',g',
                              'relative': True,

                              'font': {'size': 12}},
                    number={'valueformat': ',',
                            'font': {'size': 15},

                               },
                    domain={'y': [0, 1], 'x': [0, 1]})],
            'layout': go.Layout(
                title={'text': 'Descontinuados:',
                       'y': 1,
                       'x': 0.5,
                       'xanchor': 'center',
                       'yanchor': 'top'},
                font=dict(color='#204a9e'),
                paper_bgcolor='#ededfc',
                plot_bgcolor='#ededfc',
                height=50
                ),

            }
    #PARTE 2.1.5
@app.callback(
    Output('Total', 'figure'),
    [Input('w_trato', 'value')])
def update_confirmed(w_trato):
    DOS1 = DOS.groupby(['Last Change', 'Sales Rep 2'])[['In process', 'Won', 'Lost', 'Discontinued','Total']].sum().reset_index()

    value_total = DOS1[DOS1['Sales Rep 2'] == w_trato]['Total'].iloc[-1] - DOS1[DOS1['Sales Rep 2'] == w_trato]['Total'].iloc[-2]
    delta_total = DOS1[DOS1['Sales Rep 2'] == w_trato]['Total'].iloc[-2] - DOS1[DOS1['Sales Rep 2'] == w_trato]['Total'].iloc[-3]
    return {
            'data': [go.Indicator(
                    mode='number+delta',
                    value=value_total,
                    delta={'reference': delta_total,
                              'position': 'right',
                              'valueformat': ',g',
                              'relative': True,

                              'font': {'size': 12}},
                    number={'valueformat': ',',
                            'font': {'size': 15},

                               },
                    domain={'y': [0, 1], 'x': [0, 1]})],
            'layout': go.Layout(
                title={'text': 'Totales:',
                       'y': 1,
                       'x': 0.5,
                       'xanchor': 'center',
                       'yanchor': 'top'},
                font=dict(color='#AC43B8'),
                paper_bgcolor='#ededfc',
                plot_bgcolor='#ededfc',
                height=50
                ),

            }

    #PARTE 2.2
@app.callback(Output('pie_chart', 'figure'),
              [Input('w_trato', 'value')])
def update_graph(w_trato):
    DOS2 = DOS.groupby(['Sales Rep 2'])[['In process', 'Won', 'Lost', 'Discontinued', 'Total']].sum().reset_index()
    new_process = DOS2[DOS2['Sales Rep 2'] == w_trato]['In process'].iloc[-1]
    new_won = DOS2[DOS2['Sales Rep 2'] == w_trato]['Won'].iloc[-1]
    new_lost = DOS2[DOS2['Sales Rep 2'] == w_trato]['Lost'].iloc[-1]
    new_discontinued = DOS2[DOS2['Sales Rep 2'] == w_trato]['Discontinued'].iloc[-1]
    colors = ['#e89005', '#078739', '#fa4257', '##4a2a0f']

    return {
        'data': [go.Pie(labels=['En proceso', 'Ganados', 'Perdidos', 'Descontinuados'],
                        values=[new_process, new_won, new_lost, new_discontinued],
                        marker=dict(colors=colors),
                        hoverinfo='label+value+percent',
                        textinfo='label+value',
                        textfont=dict(size=13),
                        hole=.5,
                        rotation=80
                        # insidetextorientation='radial',
                        )],

        'layout': go.Layout(
            # width=800,
            # height=520,
            plot_bgcolor='#ededfc',
            paper_bgcolor='#ededfc',
            hovermode='closest',
            title={
                'text': 'Tratos de: ' + (w_trato),

                'y': 0.93,
                'x': 0.5,
                'xanchor': 'center',
                'yanchor': 'top'},
            titlefont={
                       'color': '#141e8c',
                       'size': 15},
            legend={
                'orientation': 'h',
                'bgcolor': '#ededfc',
                'xanchor': 'center', 'x': 0.5, 'y': -0.07},
            font=dict(
                family="sans-serif",
                size=12,
                color='black')
            ),
        }

    #PARTE 2.3
@app.callback(Output('line_chart', 'figure'),
              [Input('w_trato', 'value')])
def update_graph(w_trato):
# main data frame
    DOS3 = DOS.groupby(['Last Change', 'Sales Rep 2'])[['In process', 'Won', 'Lost', 'Discontinued','Total']].sum().reset_index()
# daily won
    DOS4 = DOS3[DOS3['Sales Rep 2'] == w_trato][['Sales Rep 2', 'Last Change', 'Total']].reset_index()
    DOS4['Total diarios'] = DOS4['Total'] - DOS4['Total'].shift(1)
    DOS4['Rolling Ave.'] = DOS4['Total diarios'].rolling(window=7).mean()

    return {
        'data': [go.Bar(x=DOS4[DOS4['Sales Rep 2'] == w_trato]['Last Change'].tail(30),
                        y=DOS4[DOS4['Sales Rep 2'] == w_trato]['Total diarios'].tail(30),

                        name='Total diarios',
                        marker=dict(
                            color='#141e8c'),
                        hoverinfo='text',
                        hovertext=
                        '<b>Fecha</b>: ' + DOS4[DOS4['Sales Rep 2'] == w_trato]['Last Change'].tail(30).astype(str) + '<br>' +
                        '<b>Total diarios</b>: ' + [f'{x:,.0f}' for x in DOS4[DOS4['Sales Rep 2'] == w_trato]['Total diarios'].tail(30)] + '<br>' +
                        '<b>Vendedor</b>: ' + DOS4[DOS4['Sales Rep 2'] == w_trato]['Sales Rep 2'].tail(30).astype(str) + '<br>'


                        ),
                 go.Scatter(x=DOS4[DOS4['Sales Rep 2'] == w_trato]['Last Change'].tail(30),
                            y=DOS4[DOS4['Sales Rep 2'] == w_trato]['Rolling Ave.'].tail(30),
                            mode='lines',
                            name='Media móvil de los útlimos siete días - Tratos ganados diarios',
                            line=dict(width=3, color='#e89005'),
                            # marker=dict(
                            #     color='green'),
                            hoverinfo='text',
                            hovertext=
                            '<b>Fecha</b>: ' + DOS4[DOS4['Sales Rep 2'] == w_trato]['Last Change'].tail(30).astype(str) + '<br>' +
                            '<b>Media Móvil (últimos 7 días)</b>: ' + [f'{x:,.0f}' for x in DOS4[DOS4['Sales Rep 2'] == w_trato]['Rolling Ave.'].tail(30)] + '<br>'
                            )],


        'layout': go.Layout(
             plot_bgcolor='#ededfc',
             paper_bgcolor='#ededfc',
             title={
                'text': 'Tratos de los últimos 30 días de: ' + (w_trato),
                'y': 0.93,
                'x': 0.5,
                'xanchor': 'center',
                'yanchor': 'top'},
             titlefont={
                        'color': '#141e8c',
                        'size': 12},

             hovermode='x',
             margin = dict(r = 0),
             xaxis=dict(title='<b>Fecha</b>',
                        color='#141e8c',
                        showline=True,
                        showgrid=True,
                        showticklabels=True,
                        linecolor='#141e8c',
                        linewidth=2,
                        ticks='outside',
                        tickfont=dict(
                            family='Arial',
                            size=12,
                            color='#141e8c'
                        )

                ),

             yaxis=dict(title='<b>Tratos totales diarios</b>',
                        color='#141e8c',
                        showline=True,
                        showgrid=True,
                        showticklabels=True,
                        linecolor='#141e8c',
                        linewidth=2,
                        ticks='outside',
                        tickfont=dict(
                           family='Arial',
                           size=12,
                           color='#141e8c'
                        )

                ),

            legend={
                'orientation': 'h',
                'bgcolor': '#ededfc',
                'xanchor': 'center', 'x': 0.5, 'y': -0.3},
                          font=dict(
                              family="sans-serif",
                              size=12,
                              color='#141e8c'),

                 )

    }

#PARTE 3 
@app.callback(Output('map', 'figure'),
              [Input('w_edo', 'value')])
def update_graph(w_edo):  ## CLIENTE?????
    TRES1 = TRES.groupby(['Latitude', 'Longitude', 'ENTIDAD'])[['In process', 'Won', 'Lost', 'Discontinued', 'Total']].max().reset_index()
    TRES2 = TRES1[TRES1['ENTIDAD'] == w_edo]

    if w_edo:
        zoom = 2
        zoom_lat = list_locations[w_edo]['Latitude']
        zoom_lon = list_locations[w_edo]['Longitude']

    return {
        'data': [go.Scattermapbox(
                         lon=TRES2['Longitude'],
                         lat=TRES2['Latitude'],
                         mode='markers',
                         marker=go.scattermapbox.Marker(
                                  size=TRES2['In process'],
                                  color=TRES2['In process'],
                                  colorscale='hsv',
                                  showscale=False,
                                  sizemode='area',
                                  opacity=0.3),

                         hoverinfo='text',
                         hovertext=
                         '<b>Estado</b>: ' + TRES2['ENTIDAD'].astype(str) + '<br>' +
                         '<b>Longitud</b>: ' + TRES2['Longitude'].astype(str) + '<br>' +
                         '<b>Latitud</b>: ' + TRES2['Latitude'].astype(str) + '<br>' +
                         '<b>Tratos en proceso</b>: ' + [f'{x:,.0f}' for x in TRES2['In process']] + '<br>' +
                         '<b>Tratos ganados</b>: ' + [f'{x:,.0f}' for x in TRES2['Won']] + '<br>' +
                         '<b>Tratos perdidos</b>: ' + [f'{x:,.0f}' for x in TRES2['Lost']] + '<br>' +
                         '<b>Tratos descontinuados</b>: ' + [f'{x:,.0f}' for x in TRES2['Discontinued']] + '<br>'

                        )],


        'layout': go.Layout(
             margin={"r": 0, "t": 0, "l": 0, "b": 0},
             # width=1820,
             # height=650,
             hovermode='closest',
             mapbox=dict(
                accesstoken='pk.eyJ1IjoicXM2MjcyNTI3IiwiYSI6ImNraGRuYTF1azAxZmIycWs0cDB1NmY1ZjYifQ.I1VJ3KjeM-S613FLv3mtkw',
                center=go.layout.mapbox.Center(lat=zoom_lat, lon=-zoom_lon),
                # style='open-street-map',
                style='dark',
                zoom=zoom
             ),
             autosize=True,

        )

    }

if __name__ == '__main__':
    app.run_server(debug=True)